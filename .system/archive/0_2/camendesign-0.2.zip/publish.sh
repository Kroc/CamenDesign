#!/usr/bin/env bash
#============================================================================================================================
# Camen Design publishing script
#============================================================================================================================

# change directory, to the directory of this script
# (because double clicking on this script uses home directory instead)
cd "`dirname "$0"`"

echo "==============================================================================="
echo "Publishing Camen Design:"
echo "==============================================================================="

# remove the previous result
echo "* Cleaning up..."
rm -rf ./upload
mkdir ./upload 2>/dev/null

# package publishing code (this is specific to camendesign.com)
echo "* Packaging publishing code..."
rm ./camendesign-0.2.zip 2>/dev/null
zip -r -9 -q ./camendesign-0.2.zip ./ -x "upload/" -x "server/index.php" -x "data/*/**" -x ".DS_Store" -x "*/.DS_Store" -x "*.tmproj"
# move the package to the website
mv ./camendesign-0.2.zip ./data/code/archive/0_2/camendesign-0.2.zip
cp ./publish.php ./data/code/archive/0_2/publish.php

# copy in the data
echo "* Copying data..."
rsync -Wrt --exclude ".DS_Store" ./data/ ./upload/

# copy in the server-side layout
echo "* Copying server code..."
rsync -Wrt --exclude ".DS_Store" ./server/ ./upload/

# run the publish script
echo "-------------------------------------------------------------------------------"
php -f publish.php
if [ $? -gt 0 ]; then echo "! Publishing website failed"; exit 1; fi

echo "==============================================================================="
echo "* Complete."
echo ""

#============================================================================================================================