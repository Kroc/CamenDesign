#!/usr/bin/env bash
#============================================================================================================================
# ReMarkable publishing script
#============================================================================================================================

# change directory, to the directory of this script
# (because double clicking on this script uses home directory instead)
cd "`dirname "$0"`"

echo "==============================================================================="
echo "Publishing ReMarkable:"
echo "==============================================================================="

cd ReMarkable
./test.php.sh
if [ $? -gt 0 ]; then echo "! ReMarkable failed tests"; exit 1; fi

# publish the documentation to ensure it’s up to date
./make.php.sh
cd ..

# copy source into website
echo "* Cleanup..."
rsync -Wrt --delete --delete-excluded --exclude "make.php.sh" ./ReMarkable/ ./data/code/remarkable/

# delete any existing package
rm ./ReMarkable.zip 2>/dev/null

# zip a new package
echo "* ZIP:"
zip -9 ./ReMarkable.zip ./ReMarkable/* -x "ReMarkable/make.php.sh" -x "ReMarkable/to.do" -x ".DS_Store"

# move it into the website for publishing
mv ./ReMarkable.zip ./data/code/remarkable/

echo "==============================================================================="
echo "* Complete."
echo ""

# publish the website
./publish.sh