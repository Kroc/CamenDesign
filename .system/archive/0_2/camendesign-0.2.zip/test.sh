#!/usr/bin/env bash

cd "`dirname "$0"`"

echo $LIST
for FILE in `find -E ./upload -regex "\.\/.*_preview\.(jpg|jpeg)" | sed 's/ /\+/g'`
do
	NAME=`echo "$FILE" | sed 's/\+/ /g'`
	echo $NAME
	jpegtran -copy none -optimize "$NAME" > "$NAME.new.jpg"
	if [ $? -gt 0 ]; then echo "! error"; exit 4; fi
	mv -f "$NAME.new.jpg" "$NAME"
done
