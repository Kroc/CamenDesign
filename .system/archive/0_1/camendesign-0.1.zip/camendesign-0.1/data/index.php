<?php //data/index.php / written by kroc camen of camen design
/* ======================================================================================================================= */
include "../code/shared.php";

//okay, so you're wondering 'what's the password'?
//if you're setting up your own website using this source code, you need to change the password to something you
//know. just enter the password that you want, *and click the "return SHA1" button* a long code (like below) will be
//displayed. copy it and change the code below with your one. that's it!
define ('_password', 'b63c40b6f8448f90e749f9e7ea550c9a96c4f0aa');

//any changes to be made? check password
if ($_POST) {
	//if the button to return the sha1 was clicked
	if (post ('sha1')) {
		die (sha1 (post ('password')));
	}
	//incorrect password?
	//todo: display "incorrect password" next to the input box, but let the page continue so as not to jar so much
	if (sha1 (post ('password')) != _password) {
		die ('incorrect password');
	}
}


/* === edit content list ================================================================================================= */
//for the edit page, if no id is provided show the list of content-entries
if (array_key_exists ('edit', $_GET)) {
	//idea: show tags down the aside, allow filtering by tag
	$cache = outputCachedPage ('page data edit tags');
	$cache->getPage ('data-edit', 'edit content');
	
	//get a list of all the content-entries
	$rows = $database->query (
		'SELECT [when], [tags], [title], [enclosure] FROM [content] ORDER BY 1 DESC;', database::query_array
	);
	
	$years = '';
	$template_year = loadTemplate ('admin/edit-yeargroup');
	
	$entries = '';
	$template_entry = loadTemplate ('admin/edit-entry');
	
	//idea: show a paperclip icon for entries with enclosures?
	while ($row =& current ($rows)) {
		$year = substr ($row[0], 0, 4);
		do {
			if ($year != substr ($row[0], 0, 4)) break;
			
			//add the comment to the list
			$entries .= repeatTemplate ($template_entry, array (
				'WHEN'  => date ('M jS', unixTime ($row[0])),
				'TAG'   => preg_match ('/\|('._content_types.')\|/', '|'.$row[1].'|', $_) ? $_[1] : '',
				//if a title is not given, use the enclosure filename if available
				'TITLE' => rssTitle (
					$row[2] ? $row[2] : ($row[3] ? reset (explode (';', $row[3])) : 'No Title')
				),
				'HREF'  => '/?'.$row[0],
				//action links
				'HREF_EDIT'   => '?'.$row[0],
				'HREF_DELETE' => '?delete='.$row[0]
			));
			
		//move to the next row, and re-loop
		} while ($row =& next ($rows));
		
		$years .= repeatTemplate ($template_year, array (
			'YEAR'    => $year,
			'ENTRIES' => $entries
		));
		$entries = '';
	}
	
	replaceTemplateTag ($cache->content, 'ENTRIES', $years);
	$cache->save ();

/* === delete content ==================================================================================================== */
} elseif ($delete_id = preg_match (_regex_content_id, get ('delete'), $_) ? $_[0] : false) {
	//has the accept button been pressed?
	if ($_POST) {
		//remove the content and return to the edit list
		deleteContent ($delete_id);
		header ('location: ?edit');
		
	} else {
		/* ~~~ display the confirmation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
		$cache = new cachedPage ('page data delete');
		if (!$cache->on_disk) {
			$cache->getPage ('data-delete', "confirm delete");
			$cache->save ();
		}
		
		//inject the preview
		replaceTemplateTag ($cache->content, 'PREVIEW', getCachedEntry ($entry='', $delete_id));
		
		$cache->output ();
	}
	
/* === add / edit content ================================================================================================ */
} else {
	//get the list of user tags from the database. this will be used to produce a list of tick boxes to toggle
	//desired tags on and off, and also validate the new tags list
	$user_tags = $database->query(
		"SELECT [tag] FROM [tags] WHERE [tag]!='".
		//ignore content-types and other reserved tags like "cc-by" &c.
		implode ("' AND [tag]!='", explode('|', _reserved_tags))."' ".
		"ORDER BY 1 ASC;", database::query_single_array
	);
	
	$preview_path = _root."/data/content-media";
	
	//if an id is provided to edit, pull the data and show the edit form
	$edit_id = reset (preg_grep (_regex_content_id, array_keys ($_GET)));
	if ($edit_id && !$_POST) {
		//pull the content from the database
		list ($data) = $database->query (
			"SELECT [title], [content], [tags], [enclosure] FROM [content] WHERE [when]=$edit_id;",
			database::query_array
		);
		$add_type = preg_match ('/\|('._content_types.')\|/', $data[2], $_) ? $_[1] : '';
		$add_licence = preg_match ('/\|('._licence_tags.')\|/', $data[2], $_) ? $_[1] : '';
		
		$add_tags = preg_grep ('/^'.implode ('|', $user_tags).'$/', explode ('|', trim ($data[2], '|')));
		$add_newtags = '';
		
		$add_title   = $data[0];
		$add_content = $data[1];
		
		$enclosure   = $data[3];
		$add_filename = reset (explode (';', $enclosure));
		
		//copy the enclosure into the preview space so that you can change content-type and it won't break
		if ($enclosure) copy (
			"$preview_path/$add_type/$add_filename", "$preview_path/_".strrchr ($add_filename, '.')
		);
		
	} else {
		$add_type       = '';		//content-type "blog", "tweet", "photo" &c.
		$add_licence    = 'cc-by';	//content licence "cc-by", "mit", "copyright" &c.
		$add_tags       = array ();	//which user-tags are ticked
		$add_newtags    = '';		//new tags to create, separated by space or comma
		$add_title      = '';		//title of content (html)
		$add_content    = '';		//body of content (html)
		$add_filename   = '';		//the filename of the enclosure, either for manual upload or re-preview
		
		$enclosure      = '';		//file attachment name, mime-type and preview name for template
	}
	$add_backdate = '';
	$edit_update = false;
	$preview = '';
	
	/* ~~~ submitted? ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
	if ($_POST) {
		//do this for real?
		$is_submitting = (strtolower (post ('add')) == 'submit');
		
		//the content type can only be one of the known types, everything else returns blank
		$add_type     = preg_match ('/^'._content_types.'$/', post ('content-type'), $_) ? $_[0] : '';
		//licence is optional, but can only be a known type
		$add_licence  = preg_match ('/^'._licence_tags.'$/',  post ('licence'),      $_) ? $_[0] : '';
		//if the entry is being backdated
		$add_backdate = preg_match (_regex_content_id,        post ('backdate'),     $_) ? $_[0] : '';
		
		//idea: add tick box to backdate to enclosure created date
		
		//for user tags that have been ticked on, find field names prepended with "tag-"
		$add_tags = array_map (
			//strip "tag-" prefix out out
			create_function ('$a', 'return substr($a,4);'),
			preg_grep ('/^tag-[a-zA-Z0-9-]{1,20}$/', array_keys ($_POST))
		);
		
		//strip out disallowed tags that are already provided by the other field controls
		$a_newtags = array_diff (
			//the list of new tags to add can be comma or space separated
			preg_grep ('/^[a-zA-Z0-9-]{1,20}$/', preg_split ('/, ?| /', post ('tags'), -1, PREG_SPLIT_NO_EMPTY)),
			//you cannot obviously create a new tag for one that is reserved or already exists
			array_merge ($user_tags, explode ('|', _disallowed_tags.'|'._reserved_tags))
		);
		$add_newtags = implode (' ', $a_newtags);
		
		$edit_update = !(bool) post ('edit-update');
		
		//concatenate the tag list to be used
		$tags = "|$add_type|".($add_licence ? "$add_licence|" : '').($add_tags ? implode ('|', $add_tags).'|' : '').
			($a_newtags ? implode ('|', $a_newtags).'|' : '')
		;
		
		//the actual content
		$add_title   = trim (post ('title'));
		$add_content = trim (post ('content'));
		
		if ($_FILES['enclosure']['error'] == 1) {
			die ("file too big");
		};
		
		//fixme: filename manually entered, does not exist error
		/* --- file upload --------------------------------------------------------------------------------------- */
		$add_filename = post ('enclosure-name');
		$is_upload    = is_uploaded_file ($_FILES['enclosure']['tmp_name']);
		if (
			($is_upload || $add_filename)
			//does this content-type allow eclosures? ('tweet' for example doesn't need them)
			&& file_exists (_root."/design/templates/content-types/$add_type.enclosure")
		) {
			//folder where the file will be stored
			$file_path = "$preview_path/$add_type";
			
			if ($is_upload) {
				//a newly uploaded file overrides a typed filename. the filename field is then updated to
				//the upload-filename so that "preview" can be clicked over and over, without having to
				//re-upload the file again and again (but can be changed at any time by uploading)
				$add_filename = $_FILES['enclosure']['name'];
			}
			
			//output filename of the enclosure, "_" for preview so that the upload folder doesn't messy
			$enclosure = $is_submitting ? $add_filename : "_".strrchr ($add_filename, '.');
			$enclosure_path = ($is_submitting ? $file_path : $preview_path)."/$enclosure";
			
			//move files around:
			if ($is_upload) {
				//move uploaded file into place
				move_uploaded_file ($_FILES['enclosure']['tmp_name'], $enclosure_path);
				
			} else {
				//if pressing submit, copy the preview file to the real filename
				if ($is_submitting && !file_exists ("$file_path/$add_filename")) {
					copy ("$preview_path/_".strrchr ($add_filename, '.'), "$file_path/$add_filename");
				}
				//if manually uploading, copy the provided upload to the preview name
				if (!$is_submitting && file_exists ("$file_path/$add_filename")) {
					copy ("$file_path/$add_filename", $enclosure_path);
				}
			}
			
			$enclosure .= ';'.mimeType (substr(strrchr($enclosure_path, '.'), 1));
			
			//if the file is an image
			if ($image_size = @getimagesize ($enclosure_path)) {
				//is the PNG transparent?
				//a very big thanks to wesley gunn for the original solution:
				//<http://php.net/manual/en/function.imagecolortransparent.php#79145>
				$is_alpha = $image_size[2] == IMAGETYPE_PNG
					? ord (file_get_contents ($enclosure_path, false, null, 25, 1)) & 4
					: false
				;
				//name of the preview file (just "_" for previews)
				$file_info = pathinfo ($enclosure_path);
				$enclosure_preview = $file_info['filename'].(
					//if an image doesn't need to be resized, the original name will be used
					$image_size[0]<=640 ? '.'.$file_info['extension'] : '_preview.'.(
						//the preview image must/will be a JPG regardless of original type,
						//unless the original is a transparent PNG, which uses a PNG preview
						$is_alpha ? 'png' : 'jpg'
					)
				);
				
				//if a preview is required
				if ($enclosure_preview != $enclosure) {
					switch ($image_size[2]) {
						case IMAGETYPE_JPEG: $image = imagecreatefromjpeg ($enclosure_path); break;
						case IMAGETYPE_PNG:  $image = imagecreatefrompng  ($enclosure_path); break;
					}
					//scale the height according to ratio
					$image_height = 640 * ($image_size[1] / $image_size[0]);
					$image_preview = imagecreatetruecolor (640, $image_height);
					//preserve transparency on PNGs
					if ($is_alpha) imagealphablending ($image_preview, false);
					//resize the image
					imagecopyresampled (
						$image_preview, $image, 0, 0, 0, 0,
						640, $image_height, $image_size[0], $image_size[1]
					);
					imagedestroy ($image);
					
					//save the preview image:
					if ($is_alpha) {
						//if transparent, preview must be PNG,
						imagesavealpha ($image_preview, true);
						@imagepng ($image_preview, ($is_submitting ? $file_path : $preview_path)."/$enclosure_preview");
					} else {
						//otherwise, use a JPG preview instead for better filesize
						//resized PNGs are very large due to added colours by anti-alias
						//why 80? http://ebrueggeman.com/article_php_image_optimization.php
						@imagejpeg ($image_preview, ($is_submitting ? $file_path : $preview_path)."/$enclosure_preview", 80);
					}
					imagedestroy ($image_preview);
				}
				$enclosure .= ";$enclosure_preview";
			}
		}
		if ($is_submitting) {
			//delete preview files after submitting
			if ($enclosure) {
				$to_delete = preg_grep ("/^_.*/", scandir ($preview_path));
				foreach ($to_delete as $filename) unlink ("$preview_path/$filename");
			}
			
			//publish information, and visit it
			header ('location: /?'.(
				//are we editing some content, or posting new?
				$edit_id
				//edit existing content:
				? editContent (
					$edit_id, $add_title, $add_content, $tags, $enclosure,
					//is this a major edit to be republished in the rss? otherwise, keep the same date
					$edit_update ? substr (timestampFromUnix (), 0, 12) : $edit_id,
					//backdating?
					$add_backdate
					
				//add a meaingless unique value to the url to force an uncached load from your browser
				).'&('.timestampFromUnix ().')'
				
				//publish the new content:
				: addContent (
					$add_backdate ? $add_backdate : substr (timestampFromUnix (), 0, 12),
					$add_title, $add_content, $tags, $enclosure
				)
			));
		} else {
			//generate the preview text
			$preview = getEntry (
				$add_backdate ? $add_backdate : ($edit_id ? $edit_id : timestampFromUnix ()),
				$add_title, $add_content, $tags, $enclosure
			);
		}
	}
	
	/* ~~~ display ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
	$cache = new cachedPage ('page data add');
	if (!$cache->on_disk) {
		$cache->getPage ('data-add', null);
		$cache->save ();
	}
	replaceTemplateTag ($cache->content, 'HEAD_TITLE',
		' · '.($edit_id ? 'editing '.($add_title ? '['.rssTitle ($add_title).']' : 'content') : 'add content')
	);
	
	$on = loadTemplate ('admin/add-option-on');
	
	//drop-down of content types
	$template = loadTemplate ('admin/add-option');
	$tags = '';
	foreach (explode ('|', _content_types) as $tag) $tags .= repeatTemplate ($template,
		array ('NAME' => $tag, 'VALUE' => $tag, 'ON' => $add_type==$tag ? $on : '')
	);
	replaceTemplateTag ($cache->content, 'CONTENT_TYPES', $tags);
	
	//drop-down of licences
	$tags = '';
	foreach (explode ('|', _licence_tags) as $tag) $tags .= repeatTemplate ($template,
		array ('NAME' => $tag, 'VALUE' => $tag, 'ON' => $add_licence==$tag ? $on : '')
	);
	$tags .= repeatTemplate ($template, (array ('NAME' => 'none', 'VALUE' => '', 'ON' => $add_licence == '' ? $on : '')));
	replaceTemplateTag ($cache->content, 'LICENCE', $tags);
	
	//checkboxes for each of the user tags
	$on = loadTemplate ('admin/add-tag-on');
	$template = loadTemplate ('admin/add-tag');
	$tags = '';
	foreach ($user_tags as &$tag) {
		$tags .= repeatTemplate ($template,
			array ('TAG' => $tag, 'ON' => in_array ($tag, $add_tags) ? $on : '')
		);
	}
	replaceTemplateTag ($cache->content, 'TAGS', $tags);
	
	replaceTemplateTagArray ($cache->content, array (
		//fill in input fields
		'TITLE'       => htmlspecialchars ($add_title),
		'CONTENT'     => htmlspecialchars ($add_content),
		'NEW_TAGS'    => $add_newtags,
		'BACKDATE'    => $add_backdate,
		'ENCLOSURE'   => htmlspecialchars ($add_filename),
		'UPDATE'      => $edit_id ? replaceTemplateTagArray (loadTemplate ('admin/edit-update'), array (
			'TIMESTAMP' => $edit_update, 'ON' => !$edit_update ? $on : ''
		)) : '',
		
		//add the preview at the top, a skip link is added to jump to the input form at the bottom of the page
		'PREVIEW'   => $preview,
		'SKIP'      => $preview ? loadTemplate ('admin/nav-skip') : ''
	));
	$cache->output ();
}

/* ==================================================================================================== code is art === */ ?>