<?php //design/index.php / css compression/caching / written by kroc camen of camen design
/* ======================================================================================================================= */
include "../code/shared.php";

header ('Content-type: text/css;charset=UTF-8');
$cache = outputCachedPage ('this-css');

$cache->content = file_get_contents ('design.css');
$cache->save ();

/* ==================================================================================================== code is art === */ ?>